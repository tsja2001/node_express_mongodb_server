/**
 * 默认配置
 */

module.exports.uuid = '4a380a09-3aab-401b-a620-1372b7e8c77a'

module.exports.mongopath = 'mongodb://localhost:27017/express-video'

module.exports.redisClient = {
  path:'192.168.0.106',
  port:6379,
  options:{password:'root'}
}