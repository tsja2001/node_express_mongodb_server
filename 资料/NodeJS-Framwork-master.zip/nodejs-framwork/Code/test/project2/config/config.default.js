/**
 * 默认配置
 */

module.exports = {
  
}
