const chalk = require('chalk')
console.log(chalk.blue('内容'))
console.log(chalk.bold('内容'))
console.log(chalk.rgb(255,60,90)('内容'))