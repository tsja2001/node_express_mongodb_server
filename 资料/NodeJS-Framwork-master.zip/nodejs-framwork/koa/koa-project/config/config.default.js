module.exports.mongoPath = "mongodb://127.0.0.1:27017/express-video"

module.exports.redisClient = {
  path:"192.168.0.106",
  port:6379,
  options:{password:'root'}
}
