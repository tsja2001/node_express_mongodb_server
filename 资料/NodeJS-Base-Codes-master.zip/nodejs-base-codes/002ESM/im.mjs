// import { value as vv } from './ex.mjs'
import val from './ex.mjs'
console.log(val);