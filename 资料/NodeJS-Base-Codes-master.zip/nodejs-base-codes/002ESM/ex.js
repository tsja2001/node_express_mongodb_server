var val = 'ex data'
// export {val as value}
export default val