// console.log(module);

var val = 'this is commonjs'
var foo = 'foo'
// module.exports = val
// module.exports = foo

// module.exports.val = val
// module.exports.foo = foo

exports.val = val
exports.foo = foo
