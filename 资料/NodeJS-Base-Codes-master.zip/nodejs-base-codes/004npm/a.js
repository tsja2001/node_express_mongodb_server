var a = '123'
console.log(a)