module.exports = {
  // 可选择的框架
  framwork:['express', 'koa', 'egg'],
  // 框架对应的下载地址
  foramworkUrl:{
    express:'git@gitee.com:beiyaoyaoyao/express-template.git',
    koa:'git@gitee.com:beiyaoyaoyao/koa-template.git',
    egg:'git@gitee.com:beiyaoyaoyao/egg-template.git'
  }
}