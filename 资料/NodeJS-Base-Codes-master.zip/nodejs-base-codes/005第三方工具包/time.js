const moment = require('moment')
var time = Date.now()
var t = moment(time).format("YYYY-MM-DD HH:mm:ss")
// console.log(time);
console.log(t);